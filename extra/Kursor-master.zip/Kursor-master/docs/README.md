---
home: true
heroImage: /kursorjs.gif
heroText: Kursorjs
tagline: Cursor style with javascript and css
actionText: Get Started →
actionLink: /guide/
features:
- title: Simple to implement
  details: Only with a few lines of code are you going to have a beautiful cursor.
- title: In trend
  details: Create great websites and with a different trend, surprise!.
- title: No dependencies
  details: Kursor is created with only javascript so you do not need to install any additional dependencies.
footer: MIT Licensed | Copyright © 2019-present Lusaxweb
---






